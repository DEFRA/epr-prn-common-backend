﻿namespace EPR.PRN.Backend.API.Dto.Exporter
{
    public class CountryDto
    {
        public string Name { get; set; } = default!;
        public string Code { get; set; } = default!;
    }
}
